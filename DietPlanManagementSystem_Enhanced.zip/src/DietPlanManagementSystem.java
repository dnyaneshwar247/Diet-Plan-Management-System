
/*
Project: AI-based Diet Plan Management System
Technologies: Java (Core + JDBC), MySQL
Structure:
1. User registration/login with authentication
2. Admin panel for diet plan management
3. Diet plan recommendation based on user input
4. AI-based fitness integration and health diagnosis
*/

// Step 1: Database Schema (MySQL)
/*
CREATE DATABASE diet_system;
USE diet_system;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE,
  password VARCHAR(50),
  age INT,
  weight DOUBLE,
  goal VARCHAR(50),
  health_conditions TEXT
);

CREATE TABLE diet_plans (
  id INT AUTO_INCREMENT PRIMARY KEY,
  goal VARCHAR(50),
  meal_time VARCHAR(20),
  food_items TEXT
);
*/

// Step 2: DBConnection.java
import java.sql.*;
class DBConnection {
    public static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/diet_system";
        String user = "root";
        String pass = "your_password";
        return DriverManager.getConnection(url, user, pass);
    }
}

// Step 3: User.java
class User {
    private String username, password, goal, healthConditions;
    private int age;
    private double weight;

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getGoal() { return goal; }
    public void setGoal(String goal) { this.goal = goal; }

    public String getHealthConditions() { return healthConditions; }
    public void setHealthConditions(String healthConditions) { this.healthConditions = healthConditions; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public double getWeight() { return weight; }
    public void setWeight(double weight) { this.weight = weight; }
}

// Step 4: UserDAO.java
class UserDAO {
    public boolean register(User user) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String sql = "INSERT INTO users (username, password, age, weight, goal, health_conditions) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, user.getUsername());
        ps.setString(2, user.getPassword());
        ps.setInt(3, user.getAge());
        ps.setDouble(4, user.getWeight());
        ps.setString(5, user.getGoal());
        ps.setString(6, user.getHealthConditions());
        return ps.executeUpdate() > 0;
    }

    public boolean login(String username, String password) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String sql = "SELECT * FROM users WHERE username=? AND password=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, username);
        ps.setString(2, password);
        ResultSet rs = ps.executeQuery();
        return rs.next();
    }

    public User getUserByUsername(String username) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String sql = "SELECT * FROM users WHERE username=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, username);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            User user = new User();
            user.setUsername(rs.getString("username"));
            user.setAge(rs.getInt("age"));
            user.setWeight(rs.getDouble("weight"));
            user.setGoal(rs.getString("goal"));
            user.setHealthConditions(rs.getString("health_conditions"));
            return user;
        }
        return null;
    }
}

// Step 5: DietPlanDAO.java
class DietPlanDAO {
    public void showPlan(String goal, String healthConditions) throws SQLException {
        Connection conn = DBConnection.getConnection();
        String sql = "SELECT meal_time, food_items FROM diet_plans WHERE goal=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, goal);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            String items = rs.getString("food_items");
            if (healthConditions != null && !healthConditions.isEmpty()) {
                if (healthConditions.toLowerCase().contains("diabetes")) {
                    items = items.replaceAll("(?i)sugar|sweet", "(restricted)");
                }
            }
            System.out.println(rs.getString("meal_time") + ": " + items);
        }
    }
}

// Step 6: Main.java
import java.util.*;
public class DietPlanManagementSystem {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        UserDAO userDAO = new UserDAO();
        DietPlanDAO dietDAO = new DietPlanDAO();

        System.out.println("1. Register\n2. Login");
        int choice = sc.nextInt();
        sc.nextLine();

        if (choice == 1) {
            User user = new User();
            System.out.print("Username: "); user.setUsername(sc.nextLine());
            System.out.print("Password: "); user.setPassword(sc.nextLine());
            System.out.print("Age: "); user.setAge(sc.nextInt());
            System.out.print("Weight: "); user.setWeight(sc.nextDouble());
            sc.nextLine();
            System.out.print("Goal (weight_loss/muscle_gain/maintenance): "); user.setGoal(sc.nextLine());
            System.out.print("Any health conditions (e.g., diabetes, heart issues): "); user.setHealthConditions(sc.nextLine());
            if (userDAO.register(user)) {
                System.out.println("Registration successful!");
            }
        } else if (choice == 2) {
            System.out.print("Username: "); String username = sc.nextLine();
            System.out.print("Password: "); String password = sc.nextLine();
            if (userDAO.login(username, password)) {
                System.out.println("Login successful!");
                User user = userDAO.getUserByUsername(username);
                System.out.println("\n--- AI Health Diagnosis ---");
                if (user.getHealthConditions() != null && !user.getHealthConditions().isEmpty()) {
                    System.out.println("Detected health issues: " + user.getHealthConditions());
                } else {
                    System.out.println("No major health issues detected.");
                }
                System.out.println("\nRecommended Diet Plan:");
                dietDAO.showPlan(user.getGoal(), user.getHealthConditions());
            } else {
                System.out.println("Invalid credentials!");
            }
        }
    }
}
